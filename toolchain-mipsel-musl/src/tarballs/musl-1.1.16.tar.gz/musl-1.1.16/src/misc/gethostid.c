long gethostid()
{
	return 0;
}
