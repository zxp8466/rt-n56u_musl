#include "libm.h"

//FIXME
long double complex csqrtl(long double complex z)
{
	return csqrt(z);
}
